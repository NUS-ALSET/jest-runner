exports.hello = function() {
    return "HELLO";
}