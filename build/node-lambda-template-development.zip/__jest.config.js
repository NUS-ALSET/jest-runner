module.exports = {
    verbose: true,
    roots: [
        '/tmp'
    ]
};