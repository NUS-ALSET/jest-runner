# jest-runner
Run jest on node files in AWS lambda
